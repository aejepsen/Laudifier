// src/app/login/login.component.ts
import { Component, signal, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { AuthService } from '../core/auth/auth.service';

@Component({
  selector: 'app-login',
  standalone: true,
  imports: [CommonModule, FormsModule],
  template: `
    <div class="login-page">
      <div class="login-card">

        <div class="brand">
          <span class="brand-icon">🏥</span>
          <h1>Laudifier</h1>
          <p>Gerador de Laudos Médicos com IA</p>
        </div>

        <div class="error-banner" *ngIf="error()">{{ error() }}</div>

        <!-- Login -->
        <form (ngSubmit)="submit()" *ngIf="!showRegister()">
          <div class="field">
            <label>Email</label>
            <input type="email" [(ngModel)]="email" name="email" placeholder="medico@hospital.com" required />
          </div>
          <div class="field">
            <label>Senha</label>
            <input type="password" [(ngModel)]="password" name="password" placeholder="••••••••" required />
          </div>
          <button type="submit" class="btn-primary" [disabled]="auth.loading()">
            {{ auth.loading() ? 'Entrando...' : 'Entrar' }}
          </button>
          <p class="toggle">Não tem conta?
            <button type="button" (click)="showRegister.set(true)">Cadastrar</button>
          </p>
        </form>

        <!-- Registro -->
        <form (ngSubmit)="register()" *ngIf="showRegister()">
          <div class="field">
            <label>Nome completo</label>
            <input type="text" [(ngModel)]="nome" name="nome" placeholder="Dr. João Silva" required />
          </div>
          <div class="field">
            <label>CRM</label>
            <input type="text" [(ngModel)]="crm" name="crm" placeholder="12345/SP" />
          </div>
          <div class="field">
            <label>Email</label>
            <input type="email" [(ngModel)]="email" name="email" placeholder="medico@hospital.com" required />
          </div>
          <div class="field">
            <label>Senha</label>
            <input type="password" [(ngModel)]="password" name="password" placeholder="Mínimo 8 caracteres" required minlength="8" />
          </div>
          <button type="submit" class="btn-primary" [disabled]="auth.loading()">
            {{ auth.loading() ? 'Cadastrando...' : 'Criar conta' }}
          </button>
          <p class="toggle">Já tem conta?
            <button type="button" (click)="showRegister.set(false)">Entrar</button>
          </p>
        </form>

      </div>
    </div>
  `,
  styles: [`
    .login-page { min-height: 100vh; display: flex; align-items: center; justify-content: center; background: linear-gradient(135deg, #0f2d5e, #1a56db); padding: 20px; }
    .login-card { background: white; border-radius: 16px; padding: 40px; width: 100%; max-width: 420px; box-shadow: 0 20px 60px rgba(0,0,0,0.25); }
    .brand { text-align: center; margin-bottom: 28px; }
    .brand-icon { font-size: 48px; display: block; margin-bottom: 8px; }
    .brand h1 { font-size: 26px; font-weight: 700; color: #0f2d5e; margin: 0 0 4px; }
    .brand p  { font-size: 13px; color: #64748b; margin: 0; }
    .error-banner { background: #fef2f2; border: 1px solid #fca5a5; color: #dc2626; border-radius: 8px; padding: 10px 14px; font-size: 13px; margin-bottom: 16px; }
    .field { margin-bottom: 16px; }
    .field label { display: block; font-size: 13px; font-weight: 600; color: #374151; margin-bottom: 6px; }
    .field input { width: 100%; padding: 10px 14px; border: 1px solid #d1d5db; border-radius: 8px; font-size: 14px; outline: none; box-sizing: border-box; }
    .field input:focus { border-color: #1a56db; box-shadow: 0 0 0 3px rgba(26,86,219,0.1); }
    .btn-primary { width: 100%; padding: 12px; background: #1a56db; color: white; border: none; border-radius: 8px; font-size: 15px; font-weight: 600; cursor: pointer; margin-bottom: 16px; }
    .btn-primary:disabled { opacity: 0.6; cursor: not-allowed; }
    .toggle { text-align: center; font-size: 13px; color: #6b7280; margin: 0; }
    .toggle button { background: none; border: none; color: #1a56db; cursor: pointer; font-weight: 600; }
  `],
})
export class LoginComponent {
  readonly auth = inject(AuthService);
  email = ''; password = ''; nome = ''; crm = '';
  error        = signal('');
  showRegister = signal(false);

  async submit() {
    this.error.set('');
    try { await this.auth.signIn(this.email, this.password); }
    catch (e: any) { this.error.set(e.message || 'Email ou senha inválidos'); }
  }

  async register() {
    this.error.set('');
    try {
      await this.auth.signUp(this.email, this.password, this.nome, this.crm);
      alert('Conta criada! Verifique seu email para confirmar.');
      this.showRegister.set(false);
    } catch (e: any) { this.error.set(e.message || 'Erro ao criar conta'); }
  }
}
