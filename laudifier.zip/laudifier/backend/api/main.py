# backend/api/main.py
"""
Laudifier — Backend FastAPI
Geração de laudos médicos com RAG + Claude knowledge fallback.
"""

import os, json, uuid, asyncio
from datetime import datetime, timezone
from typing import Optional

from fastapi import FastAPI, Depends, HTTPException, UploadFile, File, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse, FileResponse
from pydantic import BaseModel
from langfuse import Langfuse

from .auth import verify_token, UserContext
from ..agents.laudo_agent import gerar_laudo_stream
from ..services.storage_service import StorageService
from ..services.laudo_service import LaudoService
from ..services.export_service import ExportService
from ..services.memory_service import LaudifierMemory
from .memory_routes import router as memory_router

langfuse = Langfuse(
    public_key=os.getenv("LANGFUSE_PUBLIC_KEY", ""),
    secret_key=os.getenv("LANGFUSE_SECRET_KEY", ""),
    host=os.getenv("LANGFUSE_HOST", "https://cloud.langfuse.com"),
)

app = FastAPI(title="Laudifier API", version="1.0.0",
              description="Gerador de laudos médicos com IA")

app.add_middleware(CORSMiddleware,
    allow_origins=os.getenv("CORS_ORIGINS", "http://localhost:4200").split(","),
    allow_credentials=True, allow_methods=["*"], allow_headers=["*"])

storage = StorageService()

# Mem0 — rotas de gerenciamento de memória
app.include_router(memory_router)


# ─── Models ────────────────────────────────────────────────────────────────────

class LaudoRequest(BaseModel):
    solicitacao:    str                     # texto do médico (ou transcrição de voz)
    especialidade:  str                     # radiologia, patologia, etc.
    dados_clinicos: dict = {}               # dados estruturados opcionais
    laudo_id:       Optional[str] = None    # para continuar editando

class FeedbackRequest(BaseModel):
    laudo_id:  str
    aprovado:  bool
    correcoes: Optional[str] = None

class TranscricaoRequest(BaseModel):
    audio_base64: str          # fallback server-side se browser não suportar


# ─── Auth ──────────────────────────────────────────────────────────────────────

@app.post("/auth/token")
async def login(email: str, password: str):
    from supabase import create_client
    sb = create_client(os.getenv("SUPABASE_URL"), os.getenv("SUPABASE_ANON_KEY"))
    r  = sb.auth.sign_in_with_password({"email": email, "password": password})
    return {"access_token": r.session.access_token, "user_id": r.user.id}


# ─── Geração de Laudo ─────────────────────────────────────────────────────────

@app.post("/laudos/gerar")
async def gerar_laudo(
    body: LaudoRequest,
    user: UserContext = Depends(verify_token),
):
    """
    Gera laudo médico via streaming SSE.
    Usa repositório Qdrant como contexto principal.
    Fallback para conhecimento base do Claude quando repositório não tem referências.
    """
    laudo_id = body.laudo_id or str(uuid.uuid4())

    trace = langfuse.trace(
        name="gerar-laudo",
        user_id=user.id,
        input={"especialidade": body.especialidade, "solicitacao": body.solicitacao[:200]},
        metadata={"laudo_id": laudo_id},
    )

    async def event_gen():
        laudo_completo = ""
        try:
            async for chunk in gerar_laudo_stream(
                solicitacao=body.solicitacao,
                especialidade=body.especialidade,
                dados_clinicos=body.dados_clinicos,
                user_id=user.id,
            ):
                if chunk.get("type") == "token":
                    laudo_completo += chunk.get("text", "")
                if chunk.get("type") == "done":
                    # Salva laudo gerado no Supabase
                    asyncio.create_task(
                        LaudoService(user.id).salvar(
                            laudo_id=laudo_id,
                            especialidade=body.especialidade,
                            solicitacao=body.solicitacao,
                            laudo=laudo_completo,
                            tipo_geracao=chunk.get("tipo_geracao", ""),
                            laudos_ref=chunk.get("laudos_ref", []),
                        )
                    )
                    trace.update(output={"laudo_id": laudo_id, "tipo_geracao": chunk.get("tipo_geracao")})
                yield f"data: {json.dumps(chunk)}\n\n"
        except Exception as e:
            yield f"data: {json.dumps({'type': 'error', 'error': str(e)})}\n\n"

    return StreamingResponse(event_gen(), media_type="text/event-stream",
                             headers={"Cache-Control": "no-cache", "X-Accel-Buffering": "no"})


@app.post("/laudos/transcrever")
async def transcrever_audio(
    audio: UploadFile = File(...),
    user:  UserContext = Depends(verify_token),
):
    """
    Transcrição server-side com Whisper (fallback quando browser não suporta Web Speech API).
    Browser-first: o Angular usa Web Speech API diretamente quando disponível.
    """
    import tempfile, whisper as wh
    contents = await audio.read()
    with tempfile.NamedTemporaryFile(suffix=".webm", delete=False) as tmp:
        tmp.write(contents)
        tmp_path = tmp.name

    model = wh.load_model(os.getenv("WHISPER_MODEL", "small"))
    result = model.transcribe(tmp_path, language="pt", fp16=False)
    os.unlink(tmp_path)
    return {"transcript": result["text"].strip()}


# ─── Laudos Salvos ────────────────────────────────────────────────────────────

@app.get("/laudos")
async def listar_laudos(
    page: int = 0, size: int = 20,
    especialidade: Optional[str] = None,
    user: UserContext = Depends(verify_token),
):
    return await LaudoService(user.id).listar(page, size, especialidade)


@app.get("/laudos/{laudo_id}")
async def get_laudo(laudo_id: str, user: UserContext = Depends(verify_token)):
    laudo = await LaudoService(user.id).get(laudo_id)
    if not laudo:
        raise HTTPException(status_code=404, detail="Laudo não encontrado")
    return laudo


@app.put("/laudos/{laudo_id}")
async def atualizar_laudo(
    laudo_id: str,
    laudo_editado: str,
    user: UserContext = Depends(verify_token),
):
    """Salva edições do médico no laudo gerado."""
    await LaudoService(user.id).atualizar(laudo_id, laudo_editado)
    return {"status": "ok"}


@app.post("/laudos/{laudo_id}/feedback")
async def feedback(
    laudo_id: str,
    body: FeedbackRequest,
    user: UserContext = Depends(verify_token),
):
    """
    Feedback do médico: aprovou ou corrigiu o laudo.
    Laudos aprovados podem ser re-indexados no Qdrant para melhorar futuras gerações.
    """
    await LaudoService(user.id).registrar_feedback(laudo_id, body.aprovado, body.correcoes)
    # Laudos aprovados: re-indexa no Qdrant + memoriza no Mem0
    if body.aprovado:
        asyncio.create_task(_re_indexar_laudo_aprovado(laudo_id, user.id))
    # Correções: Mem0 aprende com as edições do médico
    if body.correcoes:
        asyncio.create_task(_memorizar_correcao(laudo_id, user.id, body.correcoes))
    return {"status": "ok"}


# ─── Exportação ───────────────────────────────────────────────────────────────

@app.get("/laudos/{laudo_id}/exportar/{formato}")
async def exportar_laudo(
    laudo_id: str,
    formato:  str,           # "pdf" | "docx" | "txt"
    user:     UserContext = Depends(verify_token),
):
    """Exporta o laudo em PDF, DOCX ou TXT para impressão/assinatura."""
    laudo = await LaudoService(user.id).get(laudo_id)
    if not laudo:
        raise HTTPException(status_code=404, detail="Laudo não encontrado")

    svc  = ExportService()
    path = await svc.exportar(laudo, formato)

    media = {"pdf": "application/pdf", "docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document", "txt": "text/plain"}
    return FileResponse(path, media_type=media.get(formato, "application/octet-stream"),
                        filename=f"laudo_{laudo_id[:8]}.{formato}")


# ─── Repositório ──────────────────────────────────────────────────────────────

@app.post("/repositorio/upload")
async def upload_laudo_referencia(
    arquivo:       UploadFile = File(...),
    especialidade: str = Form("geral"),
    tipo_laudo:    str = Form(""),
    user:          UserContext = Depends(verify_token),
):
    """
    Adiciona laudos ao repositório de referência via pipeline de ingestão.
    Apenas médicos com role 'admin' podem adicionar ao repositório.
    """
    if user.role != "admin":
        raise HTTPException(status_code=403, detail="Apenas administradores podem adicionar ao repositório")

    job_id   = str(uuid.uuid4())
    contents = await arquivo.read()
    url      = storage.upload_document(contents, arquivo.filename, user.id)

    asyncio.create_task(_ingerir_laudo_repositorio(
        job_id=job_id, url=url, filename=arquivo.filename,
        especialidade=especialidade, tipo_laudo=tipo_laudo, user_id=user.id,
    ))
    return {"job_id": job_id, "status": "queued"}


# ─── Dashboard ────────────────────────────────────────────────────────────────

@app.get("/dashboard/stats")
async def dashboard_stats(user: UserContext = Depends(verify_token)):
    svc = LaudoService(user.id)
    return await svc.get_stats()


# ─── Health ────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    try:
        from qdrant_client import QdrantClient
        QdrantClient(url=os.getenv("QDRANT_URL"), api_key=os.getenv("QDRANT_API_KEY") or None).get_collections()
        qdrant_ok = True
    except Exception:
        qdrant_ok = False
    return {"status": "healthy" if qdrant_ok else "degraded", "version": "1.0.0",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "services": {"qdrant": "ok" if qdrant_ok else "error"}}


# ─── Background tasks ─────────────────────────────────────────────────────────

async def _re_indexar_laudo_aprovado(laudo_id: str, user_id: str):
    """Re-indexa laudo aprovado no Qdrant para enriquecer o repositório."""
    try:
        laudo = await LaudoService(user_id).get(laudo_id)
        if laudo:
            from pipeline.index import index_laudos
            await index_laudos([{
                "content":       laudo["laudo"],
                "source_name":   f"aprovado_{laudo_id[:8]}",
                "especialidade": laudo["especialidade"],
                "tipo_laudo":    laudo.get("tipo_laudo", ""),
                "aprovado":      True,
            }])
    except Exception as e:
        print(f"[Re-indexação] Erro: {e}")


async def _ingerir_laudo_repositorio(job_id, url, filename, especialidade, tipo_laudo, user_id):
    try:
        from pipeline.run_pipeline import ingerir_laudo
        await ingerir_laudo(url, filename, especialidade, tipo_laudo, user_id)
    except Exception as e:
        print(f"[Ingestão] Erro: {e}")


async def _memorizar_correcao(laudo_id: str, user_id: str, correcoes: str):
    """Mem0 aprende com as correções que o médico fez no laudo."""
    try:
        laudo = await LaudoService(user_id).get(laudo_id)
        if laudo and laudo.get("laudo_editado"):
            mem = LaudifierMemory()
            await mem.memorizar_correcao(
                medico_id=user_id,
                laudo_original=laudo.get("laudo", ""),
                laudo_editado=laudo["laudo_editado"],
                especialidade=laudo.get("especialidade", ""),
            )
    except Exception as e:
        print(f"[Mem0 correção] Erro: {e}")
